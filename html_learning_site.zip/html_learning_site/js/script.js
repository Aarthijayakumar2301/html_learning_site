// Optional JavaScript functionality
console.log("HTML Learning Website Loaded!");
