<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;video&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<video>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;video&gt;</code> tag is used to embed video content in an HTML document. It supports multiple video formats and can include controls, autoplay, looping, and more.";

      $attributes = [
        "src" => "Specifies the URL of the video file.",
        "controls" => "Displays video controls like play, pause, volume, etc.",
        "autoplay" => "Starts playing the video automatically when the page loads.",
        "loop" => "Replays the video automatically after it ends.",
        "muted" => "Mutes the audio of the video.",
        "poster" => "Specifies an image to show before the video plays.",
        "width" => "Sets the width of the video player.",
        "height" => "Sets the height of the video player."
      ];

      $bestPractices = [
        "Always provide multiple source formats for better browser compatibility.",
        "Use the <code>controls</code> attribute for user interaction.",
        "Avoid autoplay unless necessary to improve user experience and accessibility.",
        "Use the <code>poster</code> attribute to show a preview image.",
        "Provide captions or subtitles when possible for accessibility."
      ];

      $codeExample = '&lt;video width="320" height="240" controls poster="poster.jpg"&gt;
  &lt;source src="movie.mp4" type="video/mp4"&gt;
  &lt;source src="movie.webm" type="video/webm"&gt;
  Your browser does not support the video tag.
&lt;/video&gt;';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <video width="320" height="240" controls poster="https://via.placeholder.com/320x240.png?text=Video+Poster">
        <source src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm" type="video/webm" />
        <source src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
