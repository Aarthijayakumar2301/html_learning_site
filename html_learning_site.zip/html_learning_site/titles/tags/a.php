<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;a&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet" />
  <style>
    code { background-color: #f4f4f4; padding: 2px 6px; border-radius: 4px; font-family: Consolas, monospace; font-weight: 600; }
    pre { background-color: #f8f9fa; padding: 1rem; border-radius: 5px; overflow-x: auto; }
    table td, table th { vertical-align: middle; }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<a>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;a&gt;</code> (anchor) tag creates hyperlinks. Use the <code>href</code> attribute to specify the URL.";
      $attributes = [
        "href" => "The URL (or link target).",
        "target" => "Where to open the linked URL: <code>_blank</code>, <code>_self</code>, etc.",
        "rel" => "Relationship of the linked URL to this page (e.g. <code>noopener</code>, <code>noreferrer</code>).",
        "title" => "Tooltip text shown on hover.",
        "download" => "Indicates this link should download a file."
      ];
      $bestPractices = [
        "Always include descriptive link text (not just 'click here').",
        "Use <code>rel=\"noopener noreferrer\"</code> when using <code>target=\"_blank\"</code>.",
        "Ensure accessibility by using meaningful link labels.",
        "Check that the <code>href</code> value is accurate."
      ];
      $codeExample = '<a href="https://example.com" target="_blank" rel="noopener noreferrer" title="Example site">Visit Example.com</a>';
      $linkHref = "https://via.placeholder.com/";
      $linkText = "Placeholder Link";
    ?>
    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <p><a href="<?php echo htmlspecialchars($linkHref); ?>"
          target="_blank"
          rel="noopener noreferrer"
          title="Placeholder"><?php echo htmlspecialchars($linkText); ?></a>
    </p>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
