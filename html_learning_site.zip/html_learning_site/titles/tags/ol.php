<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;ol&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<ol>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;ol&gt;</code> tag is used to define an ordered (numbered) list. Each list item is wrapped inside a <code>&lt;li&gt;</code> element. The list items will automatically be numbered.";
      $attributes = [
        "type" => "Defines the type of marker (1, A, a, I, i).",
        "start" => "Defines the starting value of the list.",
        "reversed" => "Reverses the order of the list items.",
        "class" => "Applies CSS classes.",
        "id" => "Specifies a unique identifier.",
        "style" => "Applies inline CSS styles."
      ];
      $bestPractices = [
        "Use <code>&lt;ol&gt;</code> for step-by-step instructions or ranked items.",
        "Combine with <code>&lt;li&gt;</code> tags only (no other content directly inside).",
        "Avoid deeply nested lists for clarity and accessibility.",
        "Use the <code>start</code> attribute to continue numbering across multiple lists."
      ];
      $codeExample = "<ol>\n  <li>Register an account</li>\n  <li>Login to the dashboard</li>\n  <li>Start learning</li>\n</ol>";
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <ol>
        <li>Register an account</li>
        <li>Login to the dashboard</li>
        <li>Start learning</li>
      </ol>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
