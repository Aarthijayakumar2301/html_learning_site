<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;button&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<button>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;button&gt;</code> tag defines a clickable button. It can contain text or images and is often used to submit forms or trigger actions on a webpage.";

      $attributes = [
        "type" => "Specifies the button behavior: <code>button</code>, <code>submit</code>, or <code>reset</code>.",
        "name" => "Name of the button used during form submission.",
        "value" => "Value associated with the button for form submission.",
        "disabled" => "Disables the button, making it unclickable.",
        "autofocus" => "Automatically focuses the button when the page loads.",
        "form" => "Associates the button with a form by ID."
      ];

      $bestPractices = [
        "Use <code>type=\"submit\"</code> for submitting forms.",
        "Use <code>type=\"button\"</code> for custom JavaScript actions.",
        "Use <code>disabled</code> attribute to prevent user interaction when needed.",
        "Always provide accessible text inside the button.",
        "Avoid using <code>&lt;a&gt;</code> for buttons; use <code>&lt;button&gt;</code> for better semantics."
      ];

      $codeExample = '&lt;button type="button"&gt;Click Me&lt;/button&gt;
&lt;button type="submit"&gt;Submit Form&lt;/button&gt;';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-4 bg-light">
      <button type="button" class="btn btn-primary me-2">Click Me</button>
      <button type="submit" class="btn btn-success">Submit Form</button>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
