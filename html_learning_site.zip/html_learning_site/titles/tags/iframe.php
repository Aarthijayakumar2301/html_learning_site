<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;iframe&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<iframe>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;iframe&gt;</code> tag embeds another HTML page within the current page. It creates an inline frame to display external or internal web content.";

      $attributes = [
        "src" => "Specifies the URL of the page to embed.",
        "width" => "Sets the width of the iframe (in pixels or percentage).",
        "height" => "Sets the height of the iframe.",
        "title" => "Provides a descriptive title for accessibility.",
        "frameborder" => "Defines whether the iframe has a border (deprecated, use CSS instead).",
        "allowfullscreen" => "Allows the iframe content to go fullscreen.",
        "loading" => "Specifies lazy loading behavior (<code>lazy</code>, <code>eager</code>, <code>auto</code>).",
        "sandbox" => "Applies extra restrictions to the content inside the iframe for security."
      ];

      $bestPractices = [
        "Always use the <code>title</code> attribute for accessibility.",
        "Use the <code>loading=\"lazy\"</code> attribute to improve page performance.",
        "Avoid using iframes for content you don’t control to prevent security risks.",
        "Use the <code>sandbox</code> attribute to increase security if embedding untrusted content."
      ];

      $codeExample = '&lt;iframe src="https://www.example.com" width="600" height="400" title="Example Site"&gt;&lt;/iframe&gt;';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <iframe 
        src="https://www.example.com" 
        width="600" 
        height="400" 
        title="Example Site" 
        style="border:1px solid #ccc;">
      </iframe>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
