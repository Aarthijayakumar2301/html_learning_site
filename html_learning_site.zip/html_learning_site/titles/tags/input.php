<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;input&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<input>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;input&gt;</code> tag is used to create interactive controls for web-based forms to accept data from the user. It is a self-closing (void) element and supports various types defined by the <code>type</code> attribute.";

      $attributes = [
        "type" => "Specifies the type of input control (text, password, email, checkbox, radio, submit, etc.).",
        "name" => "Defines the name of the input for form submission.",
        "value" => "Specifies the initial value of the input.",
        "placeholder" => "Provides a short hint displayed in the input before the user enters a value.",
        "required" => "Indicates that the input must be filled out before submitting.",
        "readonly" => "Specifies that the input cannot be modified by the user.",
        "disabled" => "Disables the input, making it uneditable and excluding it from form submission.",
        "maxlength" => "Limits the maximum number of characters allowed.",
        "min" => "Defines the minimum value for numeric inputs.",
        "max" => "Defines the maximum value for numeric inputs.",
        "step" => "Specifies the legal number intervals for numeric inputs."
      ];

      $bestPractices = [
        "Always specify the <code>type</code> attribute for clarity and proper behavior.",
        "Use <code>name</code> attribute to identify form data upon submission.",
        "Use <code>placeholder</code> to guide users, but never rely on it as a label.",
        "Use <code>required</code> to enforce mandatory inputs.",
        "Avoid using <code>disabled</code> if the data still needs to be submitted; use <code>readonly</code> instead.",
        "Validate inputs both client-side and server-side."
      ];

      $codeExample = '&lt;form action="/submit.php" method="post"&gt;
  &lt;label for="username"&gt;Username:&lt;/label&gt;
  &lt;input type="text" id="username" name="username" placeholder="Enter your username" required /&gt;

  &lt;label for="password"&gt;Password:&lt;/label&gt;
  &lt;input type="password" id="password" name="password" required /&gt;

  &lt;input type="submit" value="Login" /&gt;
&lt;/form&gt;';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo $codeExample; ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-4 bg-light">
      <form action="#" method="post">
        <div class="mb-3">
          <label for="username" class="form-label">Username:</label>
          <input type="text" id="username" name="username" class="form-control" placeholder="Enter your username" required />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password:</label>
          <input type="password" id="password" name="password" class="form-control" required />
        </div>
        <input type="submit" value="Login" class="btn btn-primary" />
      </form>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
