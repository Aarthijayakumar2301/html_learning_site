<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;img&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<img>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;img&gt;</code> tag is used to embed images in an HTML document. It is a self-closing (void) element and requires at minimum the <code>src</code> (source) and <code>alt</code> (alternative text) attributes.";
      $attributes = [
        "src" => "Specifies the path to the image file.",
        "alt" => "Specifies alternative text when the image cannot be displayed (important for accessibility).",
        "width" => "Sets the width of the image (in pixels or %).",
        "height" => "Sets the height of the image.",
        "title" => "Provides additional information as a tooltip on hover.",
        "loading" => "Specifies lazy loading (<code>lazy</code>, <code>eager</code>, <code>auto</code>)."
      ];
      $bestPractices = [
        "Always use the <code>alt</code> attribute for accessibility.",
        "Use optimized image formats (like WebP or compressed JPG/PNG).",
        "Use <code>loading=\"lazy\"</code> to improve page performance for images below the fold.",
        "Set width and height to prevent layout shift."
      ];
      $codeExample = '&lt;img src="https://via.placeholder.com/300x200" alt="Placeholder image" width="300" height="200" /&gt;';
      $imageSrc = "/assets/images/banner1.jpg";
      $imageAlt = "Placeholder image";
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr>
          <th>Attribute</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo $codeExample; ?></code></pre>

    <h4>Output:</h4>
    <img src="<?php echo $imageSrc; ?>" alt="<?php echo htmlspecialchars($imageAlt); ?>" width="300" height="200" class="img-thumbnail" />

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
