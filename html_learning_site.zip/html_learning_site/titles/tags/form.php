<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;form&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<form>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;form&gt;</code> tag is used to create an HTML form for user input. It can contain form elements such as <code>&lt;input&gt;</code>, <code>&lt;textarea&gt;</code>, <code>&lt;button&gt;</code>, <code>&lt;select&gt;</code>, etc.";

      $attributes = [
        "action" => "Specifies where to send the form data when submitted (URL).",
        "method" => "Defines the HTTP method: <code>get</code> (default) or <code>post</code>.",
        "target" => "Specifies where to display the response after submitting.",
        "autocomplete" => "Enables/disables automatic completion of form fields.",
        "novalidate" => "Disables native HTML5 validation.",
        "enctype" => "Specifies encoding type for form data when method is POST."
      ];

      $bestPractices = [
        "Use <code>method=\"post\"</code> for sensitive data like passwords.",
        "Always include a proper <code>action</code> URL or leave it blank to submit to the same page.",
        "Use <code>label</code> tags for accessibility.",
        "Use <code>required</code> attribute where appropriate for validation.",
        "Group related fields with <code>&lt;fieldset&gt;</code> and <code>&lt;legend&gt;</code> when necessary."
      ];

      $codeExample = "<form action=\"/submit.php\" method=\"post\">\n  <label for=\"name\">Name:</label>\n  <input type=\"text\" id=\"name\" name=\"name\" required>\n\n  <label for=\"email\">Email:</label>\n  <input type=\"email\" id=\"email\" name=\"email\" required>\n\n  <button type=\"submit\">Submit</button>\n</form>";
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-4 bg-light">
      <form action="#" method="post">
        <div class="mb-3">
          <label for="name" class="form-label">Name:</label>
          <input type="text" id="name" name="name" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email:</label>
          <input type="email" id="email" name="email" class="form-control" required />
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
