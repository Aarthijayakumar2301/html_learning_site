<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;audio&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<audio>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;audio&gt;</code> tag is used to embed sound content in an HTML document. It supports multiple audio formats and can include controls, autoplay, looping, and more.";

      $attributes = [
        "src" => "Specifies the URL of the audio file.",
        "controls" => "Displays audio controls like play, pause, volume, etc.",
        "autoplay" => "Starts playing the audio automatically when the page loads.",
        "loop" => "Replays the audio automatically after it ends.",
        "muted" => "Mutes the audio by default.",
        "preload" => "Specifies if and how the audio should be loaded (auto, metadata, none)."
      ];

      $bestPractices = [
        "Always provide multiple source formats for better browser compatibility.",
        "Use the <code>controls</code> attribute for user interaction.",
        "Avoid autoplay to prevent disrupting user experience unless necessary.",
        "Use <code>preload</code> attribute wisely to optimize performance.",
        "Provide captions or transcripts when possible for accessibility."
      ];

      $codeExample = '&lt;audio controls&gt;
  &lt;source src="audio.mp3" type="audio/mpeg"&gt;
  &lt;source src="audio.ogg" type="audio/ogg"&gt;
  Your browser does not support the audio element.
&lt;/audio&gt;';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <audio controls>
        <source src="https://interactive-examples.mdn.mozilla.net/media/examples/t-rex-roar.mp3" type="audio/mpeg" />
        <source src="https://interactive-examples.mdn.mozilla.net/media/examples/t-rex-roar.ogg" type="audio/ogg" />
        Your browser does not support the audio element.
      </audio>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
