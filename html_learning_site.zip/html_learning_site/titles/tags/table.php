<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;table&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<table>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;table&gt;</code> tag is used to create tabular data. It organizes content into rows and columns using related tags like <code>&lt;tr&gt;</code>, <code>&lt;td&gt;</code>, and <code>&lt;th&gt;</code>.";

      $attributes = [
        "border" => "Sets the border width (not recommended in HTML5, use CSS instead).",
        "cellpadding" => "Specifies the space between the cell wall and the cell content.",
        "cellspacing" => "Specifies the space between cells (deprecated in HTML5).",
        "class" => "Applies CSS classes.",
        "id" => "Assigns a unique identifier.",
        "style" => "Applies inline CSS styles.",
        "width" => "Defines table width (in pixels or %)."
      ];

      $bestPractices = [
        "Use <code>&lt;thead&gt;</code>, <code>&lt;tbody&gt;</code>, and <code>&lt;tfoot&gt;</code> to organize complex tables.",
        "Use <code>&lt;th&gt;</code> for headers, not just bold text.",
        "Avoid inline styles — use CSS for styling.",
        "Ensure tables are responsive on smaller screens (use Bootstrap's <code>.table-responsive</code> if needed)."
      ];

      $codeExample = "<table>\n  <tr>\n    <th>Name</th>\n    <th>Age</th>\n  </tr>\n  <tr>\n    <td>John</td>\n    <td>25</td>\n  </tr>\n  <tr>\n    <td>Jane</td>\n    <td>30</td>\n  </tr>\n</table>";
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <table class="table table-bordered">
        <thead class="table-light">
          <tr>
            <th>Name</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>John</td>
            <td>25</td>
          </tr>
          <tr>
            <td>Jane</td>
            <td>30</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
