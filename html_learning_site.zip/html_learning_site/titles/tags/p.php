<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>&lt;p&gt; Tag - HTML Reference</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet" />
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
    }
    pre {
      background-color: #f8f9fa;
      padding: 1rem;
      border-radius: 5px;
      overflow-x: auto;
    }
    table td, table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <?php
      $tag = "<p>";
      $title = htmlspecialchars($tag) . " Tag - HTML Reference";
      $description = "The <code>&lt;p&gt;</code> tag defines a paragraph of text in HTML. It is a block-level element and automatically adds space above and below its content.";
      $attributes = [
        "align" => "Specifies the alignment of the paragraph text (deprecated in HTML5).",
        "class" => "Applies a CSS class to the element.",
        "id" => "Specifies a unique ID for styling or scripting.",
        "style" => "Applies inline CSS styles directly to the tag.",
        "title" => "Provides additional tooltip text on hover."
      ];
      $bestPractices = [
        "Avoid using the deprecated <code>align</code> attribute; use CSS instead.",
        "Use semantic <code>&lt;p&gt;</code> for readable text blocks.",
        "Avoid placing block-level elements inside a paragraph.",
        "Use paragraphs for each logical section of your content."
      ];
      $codeExample = '<p>This is a simple paragraph of text.</p>';
    ?>

    <h2 class="text-primary"><?php echo htmlspecialchars($tag); ?> Tag</h2>
    <p><?php echo $description; ?></p>

    <h4>Common Attributes:</h4>
    <table class="table table-bordered table-sm">
      <thead class="table-light">
        <tr><th>Attribute</th><th>Description</th></tr>
      </thead>
      <tbody>
        <?php foreach ($attributes as $attr => $desc): ?>
          <tr>
            <td><code><?php echo htmlspecialchars($attr); ?></code></td>
            <td><?php echo $desc; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h4>Best Practices:</h4>
    <ul>
      <?php foreach ($bestPractices as $tip): ?>
        <li><?php echo $tip; ?></li>
      <?php endforeach; ?>
    </ul>

    <h4>Example Code:</h4>
    <pre><code><?php echo htmlspecialchars($codeExample); ?></code></pre>

    <h4>Output:</h4>
    <div class="border p-3 bg-light">
      <p>This is a simple paragraph of text.</p>
    </div>

    <div class="mt-4">
      <a href="/titles/experiment0.php" class="btn btn-secondary">← Back</a>
    </div>
  </div>
</body>
</html>
