<?php include '../header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>HTML Tag Reference Table</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: Consolas, monospace;
      font-weight: 600;
      color: black;
    }
    tbody tr:hover {
      background-color: #f1f9ff;
    }
    .highlighted {
      background-color: #fff3cd !important; /* Bootstrap warning bg */
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <section>
      <h2 class="mb-4 text-primary">HTML Tag Reference Table</h2>
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle shadow-sm bg-white">
          <thead class="table-info text-dark">
            <tr>
              <th>Tag</th>
              <th>Description</th>
              <th>Output</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $tags = [
              ["img", "Embeds an image", "/titles/tags/img.php", "Image Tag"],
              ["a", "Defines a hyperlink", "/titles/tags/a.php", "Anchor tag"],
              ["p", "Defines a paragraph", "/titles/tags/p.php", "Paragraph tag"],
              ["h1", "Defines a top-level heading", "/titles/tags/h1.php", "Heading tag"],
              ["ul", "Defines an unordered (bulleted) list", "/titles/tags/ul.php", "Unordered List tag"],
              ["ol", "Defines an ordered (numbered) list", "/titles/tags/ol.php", "Ordered List tag"],
              ["table", "Defines a table", "/titles/tags/table.php", "Table tag"],
              ["form", "Defines an input form", "/titles/tags/form.php", "Form tag"],
              ["input", "Defines an input field", "/titles/tags/input.php", "Input tag"],
              ["button", "Defines a clickable button", "/titles/tags/button.php", "Button tag"],
              ["video", "Embeds a video file", "/titles/tags/video.php", "Video tag"],
              ["audio", "Embeds an audio file", "/titles/tags/audio.php", "Audio tag"],
              ["br", "Inserts a single line break", "/titles/tags/br.php", "BR tag"],
              ["hr", "Creates a horizontal line", "/titles/tags/hr.php", "HR tag"],
              ["iframe", "Embeds another webpage", "/titles/tags/iframe.php", "Iframe tag"]
            ];

            $highlightTag = isset($_GET['tag']) ? $_GET['tag'] : null;

            foreach ($tags as $tag) {
              $tagName = $tag[0];
              $isHighlighted = ($highlightTag === $tagName) ? 'highlighted' : '';
              $rowId = "tag-" . htmlspecialchars($tagName);
              echo "<tr id='$rowId' class='$isHighlighted'>
                      <td><code>&lt;$tagName&gt;</code></td>
                      <td>{$tag[1]}</td>
                      <td><a href='{$tag[2]}' class='btn btn-outline-primary btn-sm'>{$tag[3]}</a></td>
                    </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <?php if ($highlightTag): ?>
    <script>
      // Auto-scroll to the highlighted tag row
      window.onload = function () {
        const highlightedRow = document.getElementById("tag-<?php echo htmlspecialchars($highlightTag); ?>");
        if (highlightedRow) {
          highlightedRow.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      };
    </script>
  <?php endif; ?>
</body>
</html>
