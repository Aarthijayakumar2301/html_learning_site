<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Simple Portfolio - Your Name</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
      background: #f4f4f4;
      color: #333;
    }
    header, footer {
      text-align: center;
      background: #222;
      color: white;
      padding: 20px 0;
    }
    nav ul {
      list-style: none;
      padding: 0;
      display: flex;
      justify-content: center;
      gap: 15px;
      margin-bottom: 30px;
    }
    nav ul li {
      display: inline;
    }
    nav ul li a {
      text-decoration: none;
      color: #333;
      font-weight: bold;
    }
    nav ul li a:hover {
      color: #007BFF;
    }
    section {
      background: white;
      padding: 20px;
      margin-bottom: 30px;
      border-radius: 5px;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }
    .projects {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }
    .project {
      background: #e9ecef;
      padding: 15px;
      border-radius: 5px;
      width: 250px;
      box-sizing: border-box;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .project h3 {
      margin-top: 0;
    }
    img {
      max-width: 100%;
      border-radius: 5px;
      margin-bottom: 10px;
    }
    footer p {
      margin: 0;
      font-size: 0.9em;
      color: #ccc;
    }
  </style>
</head>
<body>

<header>
  <h1>AARTHI JAYAKUMAR </h1>
  <p>Web Developer & Designer</p>
</header>

<nav>
  <ul>
    <li><a href="#about">About Me</a></li>
    <li><a href="#projects">Projects</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
</nav>

<section id="about">
  <h2>About Me</h2>
  <p>Hello! I'm a passionate web developer with experience in HTML, CSS, and JavaScript. I love building beautiful and functional websites.</p>
</section>

<section id="projects">
  <h2>Projects</h2>
  <div class="projects">
    <div class="project">
      <img src="/assets/images/i.jpg" alt="Project 1 Screenshot" />
      <h3>Project One</h3>
      <p>A simple website built with HTML and CSS.</p>
    </div>
    <div class="project">
      <img src="/assets/images/2.jpg" alt="Project 2 Screenshot" />
      <h3>Project Two</h3>
      <p>JavaScript app that fetches data from an API.</p>
    </div>
    <div class="project">
      <img src="/assets/images/4.jpg" alt="Project 3 Screenshot" />
      <h3>Project Three</h3>
      <p>Responsive portfolio website design.</p>
    </div>
  </div>
</section>

<section id="contact">
  <h2>Contact Me</h2>
  <p>If you'd like to get in touch, please email me at <a href="mailto:aarthijayakumar2301@gmail.com">aarthijayakumar2301@gmail.com</a>.</p>
</section>

<footer>
  <p>&copy; 2025 Aarthi. All rights reserved.</p>
</footer>

</body>
</html>
