<?php include '../data/experiments.php'; ?>
<?php include '../header.php'; ?>

<main class="container py-4">
    <h2 class="mb-4">HTML Experiments</h2>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($experiments as $key => $exp): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $exp['title']; ?></h5>
                        <p class="card-text"><?php echo $exp['desc']; ?></p>

                        <?php if ($key === 'title0'): ?>
                            <a href="experiment0.php" class="btn btn-primary">Learn</a>
                        <?php elseif ($key === 'title1'): ?>
                            <a href="experiment1.php" class="btn btn-primary">Learn</a>
                        <?php else: ?>
                            <a href="../lesson.php?lesson=<?php echo urlencode($key); ?>" class="btn btn-primary">Learn</a>
                        <?php endif; ?>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<?php include '../footer.php'; ?>
