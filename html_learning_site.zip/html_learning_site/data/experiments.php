<?php
$experiments = [
    'title0' => [
        'title' => 'HTML Basics',
        'desc' => 'Learn the fundamentals of HTML including tags, elements, and attributes.'
    ],
    'title1' => [
        'title' => 'Creating a Webpage',
        'desc' => 'Step-by-step guide to building a complete webpage using essential HTML tags.'
    ],
];
?>
