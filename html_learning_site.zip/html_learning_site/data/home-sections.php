<?php
$homeSections = [
    [
        "title" => "What is HTML?",
        "color" => "primary",
        "text" => "HTML stands for HyperText Markup Language. It is the standard language used to structure content on the web."
    ],
    [
        "title" => "Why Learn HTML?",
        "color" => "success",
        "text" => "HTML is the foundation of all websites. Learning HTML allows you to build, understand, and modify web pages."
    ],
    [
        "title" => "How to Learn?",
        "color" => "info",
        "text" => "Start by understanding basic tags, structure, and formatting. Practice regularly and follow our step-by-step experiments."
    ],
    [
        "title" => "Who Can Learn?",
        "color" => "warning",
        "text" => "Anyone! Whether you're a student, designer, or just curious — HTML is a great place to begin learning code."
    ],
    [
        "title" => "Where is HTML Used?",
        "color" => "danger",
        "text" => "HTML is used everywhere on the web — from personal blogs to large enterprise websites. It’s the backbone of web content."
    ],
    [
        "title" => "What's Next After HTML?",
        "color" => "dark",
        "text" => "Once you're comfortable with HTML, you can move on to CSS for styling and JavaScript for interactivity to build dynamic websites."
    ]
];
